# Security Notes

## Implemented

- Helmet security headers.
- CORS support.
- Global rate limiting.
- Dedicated login rate limiting.
- Dedicated result lookup rate limiting.
- JWT admin sessions.
- HTTP-only admin cookie.
- XSS sanitization for key text inputs.
- Upload MIME validation and file-size limits.
- Soft deletes for core ERP records.
- Activity logs for result views, result CRUD, gallery CRUD, and branding updates.
- Hidden storage path model through Cloudinary URLs and future S3-compatible storage.

## Required Before Production

- Use a long random `JWT_SECRET`.
- Rotate the bootstrap admin password after first login.
- Restrict CORS to known domains.
- Store secrets only in the hosting platform secret manager.
- Add object-level permission checks if staff roles are scoped by department or module.
- Place PDF marksheets in private S3 buckets when moving beyond Cloudinary public URLs.
- Add malware scanning for uploaded files if accepting files from public users.
- Run dependency audits in CI.

## RBAC Model

The schema supports `SUPER_ADMIN`, `ADMIN`, and `STAFF` with per-module permissions. The current Express runtime has a bootstrap admin guard; the Prisma schema is ready for full role and permission enforcement during the data-layer migration.
