# API Reference

## Public

- `GET /api/settings/public` returns branding values.
- `GET /api/result/categories` returns active result categories.
- `POST /api/result/check` verifies category, registration or roll number, and date of birth.
- `GET /api/result/verify/:code` verifies a published result code.
- `GET /api/gallery/categories` returns active gallery categories.
- `GET /api/public/gallery` returns public gallery images.
- `POST /api/chat` streams OpenRouter chatbot replies with Gemini fallback.
- `POST /api/solve-question` handles Gemini text, image, and PDF analysis.
- `POST /api/contact` stores contact inquiries.
- `POST /api/lead` stores AI lead-capture submissions.

## Admin Auth

- `POST /api/admin/login`
- `POST /api/admin/logout`
- `GET /api/admin/check-auth`

## Admin Results

- `GET /api/admin/result-categories`
- `POST /api/admin/result-categories`
- `PUT /api/admin/result-categories/:id`
- `DELETE /api/admin/result-categories/:id`
- `GET /api/admin/results`
- `POST /api/admin/results`
- `PUT /api/admin/results/:id`
- `DELETE /api/admin/results/:id`
- `POST /api/admin/results/import`

Result imports expect CSV headers such as:

```csv
categorySlug,resultMode,registrationNumber,rollNumber,studentName,dob,className,session,totalMarks,maxMarks,percentage,grade,rank,remarks,published,pdfUrl,externalUrl
class-10-result,dynamic,SDP26001,10A01,Aarav Singh,2011-08-12,10,2026-27,455,500,91,A+,1,Excellent,true,,
```

## Admin Gallery

- `GET /api/admin/gallery-categories`
- `POST /api/admin/gallery-categories`
- `PUT /api/admin/gallery-categories/:id`
- `DELETE /api/admin/gallery-categories/:id`
- `GET /api/admin/gallery`
- `POST /api/admin/gallery`
- `PUT /api/admin/gallery/:id`
- `DELETE /api/admin/gallery/:id`

## Admin Settings

- `GET /api/admin/dashboard`
- `GET /api/admin/students`
- `GET /api/admin/activity-logs`
- `GET /api/admin/settings/branding`
- `PUT /api/admin/settings/branding`
- `POST /api/admin/settings/branding/upload`
