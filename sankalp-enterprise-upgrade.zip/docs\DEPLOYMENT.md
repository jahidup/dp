# Deployment Guide

## Local Setup

1. Copy `.env.example` to `.env`.
2. Set `ADMIN_EMAIL`, `ADMIN_PASSWORD`, `JWT_SECRET`, `MONGODB_URI`, AI keys, and storage keys.
3. Run:

```bash
npm install
npm start
```

Open `http://localhost:3000`.

## Docker

```bash
docker compose up --build
```

This starts the app, MongoDB, PostgreSQL, and MinIO. MongoDB supports the current runtime; PostgreSQL is available for Prisma migrations and future service migration.

## Prisma

The target PostgreSQL schema lives in `prisma/schema.prisma`.

```bash
npm run prisma:generate
npx prisma migrate dev --name init
```

Use `npm run prisma:migrate` in production after migrations are committed.

## Vercel

The existing `vercel.json` routes all requests to `server.js`. Configure all environment variables in the Vercel project settings. For persistent uploads, use Cloudinary or S3-compatible storage instead of local filesystem storage.

## Production Checklist

- Replace `ADMIN_PASSWORD` and `JWT_SECRET`.
- Use HTTPS-only cookies in production.
- Configure MongoDB Atlas or a managed MongoDB instance.
- Configure PostgreSQL before beginning Prisma runtime migration.
- Configure Cloudinary or S3-compatible storage.
- Set OpenRouter and Gemini keys.
- Enable platform logs and uptime monitoring.
- Run `npm run check` before deployment.
