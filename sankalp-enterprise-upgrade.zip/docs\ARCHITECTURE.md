# Sankalp Enterprise Architecture

## Current Runtime

The supplied project is an Express and static-page application. The upgrade keeps that runtime stable while adding enterprise modules around the existing deployment model:

- Public pages: static HTML, shared CSS, and `assets/enterprise.js`.
- Backend: `server.js` with REST APIs, JWT admin auth, rate limiting, upload validation, Cloudinary storage, and Mongoose runtime models.
- Database compatibility: MongoDB is still supported for the existing app. A complete PostgreSQL target schema is included in `prisma/schema.prisma` for the requested ERP migration path.
- Storage: Cloudinary is active in the existing code path. S3-compatible storage variables and MinIO compose service are included for future file storage migration.

## Modules

- Branding: dynamic logo, favicon, institute name, and primary color settings.
- Results: categories, dynamic marksheets, PDF marksheets, external links, student photo data, subject rows, result verification, bulk CSV import, and audit logs.
- Gallery: category management, image metadata, featured images, public filters, search, and lightbox viewing.
- Admin: dashboard stats, result/category management, gallery/category management, branding, students, chatbot overview, system settings, and activity logs.
- AI: OpenRouter chat mode and Gemini file analysis mode remain available through the existing endpoints.

## Production Migration Notes

The fastest low-risk deployment path is to deploy this upgraded Express app first, then migrate the runtime data layer from Mongoose models to Prisma services module by module. The Prisma schema is intentionally table-complete so the migration can be incremental instead of a rewrite under deadline pressure.
